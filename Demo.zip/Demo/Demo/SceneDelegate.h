//
//  SceneDelegate.h
//  Demo
//
//  Created by LYW on 2021/6/3.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

