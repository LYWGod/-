//
//  ViewController.m
//  Demo
//
//  Created by LYW on 2021/6/3.
//

#import "ViewController.h"
#import "MineLoveOrCreatCell.h"
#import "UIColor+Extend.h"
#import <MJExtension.h>
#import <Masonry.h>
#import <WebKit/WebKit.h>
#import "AwemeListController.h"
#import "ScalePresentAnimation.h"
#import "ScaleDismissAnimation.h"
#import "SwipeLeftInteractiveTransition.h"
#import "MineViewModel.h"
#import "MineLoveOrCreatVideoModel.h"
#import "LoadMoreControl.h"
#import <MJRefresh.h>
#import "NetworkHelper.h"
#import "GKDYVideoModel.h"

#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)

//size
#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height


@interface ViewController ()<UICollectionViewDataSource, UICollectionViewDelegate,UIViewControllerTransitioningDelegate>

/** collectionView数据源 */
@property (nonatomic,strong) NSMutableArray *dataSource;

@property (nonatomic, assign) NSInteger                        pageIndex;
@property (nonatomic, assign) NSInteger                        pageSize;

@property (nonatomic, strong) ScalePresentAnimation            *scalePresentAnimation;
@property (nonatomic, strong) ScaleDismissAnimation            *scaleDismissAnimation;
@property (nonatomic, strong) SwipeLeftInteractiveTransition   *swipeLeftInteractiveTransition;
@property (nonatomic, strong) MineViewModel *viewModel;
@property (nonatomic, strong) LoadMoreControl                  *loadMore;
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
    
    //    0>>>>0-9    == 0-9
    //    1>>>>10-19  == 0-9
    //    2>>>>20-29  == 0-9   currentPage % 10
    
    NSLog(@"%d",23 % 10);
    
}

#pragma mark - network
- (void)loadData:(NSInteger)pageIndex pageSize:(NSInteger)pageSize {
    
    NSString *videoPath = [[NSBundle mainBundle] pathForResource:@"video1" ofType:@"json"];
    
    NSData *jsonData = [NSData dataWithContentsOfFile:videoPath];
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves error:nil];
    
    NSArray *videoList = dic[@"data"][@"video_list"];
    
    NSMutableArray *tempArr = [NSMutableArray new];
    for (NSDictionary *dict in videoList) {
        GKDYVideoModel *model = [GKDYVideoModel mj_objectWithKeyValues:dict];
        [tempArr addObject:model];
        
    }
    
    NSArray<GKDYVideoModel *> *array = tempArr;
    self.pageIndex++;

    [UIView setAnimationsEnabled:NO];

    [self.collectionView performBatchUpdates:^{
        [self.dataSource addObjectsFromArray:array];
        NSMutableArray<NSIndexPath *> *indexPaths = [NSMutableArray array];
        for(NSInteger row = self.dataSource.count - array.count; row<self.dataSource.count; row++) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:1];
            [indexPaths addObject:indexPath];
        }
        [self.collectionView insertItemsAtIndexPaths:indexPaths];
    } completion:^(BOOL finished) {

        [UIView setAnimationsEnabled:YES];
    }];

    [self.loadMore endLoading];

//    __weak typeof (self) wself = self;
//    [self.viewModel loadNewDataOfVideoListWithPage:pageIndex withSuccess:^(NSArray * _Nonnull list) {
//
//        NSArray<LoveOrCreatRecordsModel *> *array = list;
//        wself.pageIndex++;
//
//        [UIView setAnimationsEnabled:NO];
//
//        [wself.collectionView performBatchUpdates:^{
//            [wself.dataSource addObjectsFromArray:array];
//            NSMutableArray<NSIndexPath *> *indexPaths = [NSMutableArray array];
//            for(NSInteger row = wself.dataSource.count - array.count; row<wself.dataSource.count; row++) {
//                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:1];
//                [indexPaths addObject:indexPath];
//            }
//            [wself.collectionView insertItemsAtIndexPaths:indexPaths];
//        } completion:^(BOOL finished) {
//
//            [UIView setAnimationsEnabled:YES];
//        }];
//
//        [wself.loadMore endLoading];
//    }];
}

//网络状态发送变化
-(void)onNetworkStatusChange:(NSNotification *)notification {
    if(![NetworkHelper isNotReachableStatus:[NetworkHelper networkStatus]]) {
        [self loadData:_pageIndex pageSize:_pageSize];
    }
}

#pragma mark - <UICollectionViewDataSource, UICollectionViewDelegate>
//UICollectionViewDataSource Delegate
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return  section == 1 ? self.dataSource.count : 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    MineLoveOrCreatCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass(MineLoveOrCreatCell.class) forIndexPath:indexPath];
    cell.titleStr = @"作品";
    cell.model = self.dataSource[indexPath.row];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    _selectIndex = indexPath.row;
    
    AwemeListController *controller = [[AwemeListController alloc] initWithVideoData:self.dataSource currentIndex:indexPath.row pageIndex:_pageIndex pageSize:_pageSize awemeType:AwemeWork];
    
    controller.transitioningDelegate = self;
    
    controller.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    self.modalPresentationStyle = UIModalPresentationCurrentContext;
    [_swipeLeftInteractiveTransition wireToViewController:controller];
    [self.navigationController presentViewController:controller animated:YES completion:nil];
    
}

#pragma mark - UIViewControllerTransitioningDelegate
- (id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    return _scalePresentAnimation;
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return _scaleDismissAnimation;
}

-(id<UIViewControllerInteractiveTransitioning>)interactionControllerForDismissal:(id<UIViewControllerAnimatedTransitioning>)animator {
    return _swipeLeftInteractiveTransition.interacting ? _swipeLeftInteractiveTransition : nil;
}

#pragma mark - UI
- (void)setupUI
{
    self.view.backgroundColor = [UIColor colorWithHex:@"#F8F8F8"];
    
    [self.view addSubview:self.collectionView];
    [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(0);
        make.right.offset(0);
        make.top.offset(120);
        make.bottom.equalTo(self.view.mas_bottom);
    }];
    
    _pageIndex = 1;
    _pageSize = 10;
    
    _scalePresentAnimation = [ScalePresentAnimation new];
    _scaleDismissAnimation = [ScaleDismissAnimation new];
    _swipeLeftInteractiveTransition = [SwipeLeftInteractiveTransition new];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onNetworkStatusChange:) name:NetworkStatesChangeNotification object:nil];
}


#pragma mark - 懒加载

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        CGFloat width = (SCREEN_WIDTH - 24 - 12) / 3;
        CGFloat height = width * 148 / 113;
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        layout.itemSize = CGSizeMake(width, height);
        layout.minimumLineSpacing = 6.0f;
        layout.minimumInteritemSpacing = 6.0f;
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor colorWithHex:@"#F8F8F8"];
        [_collectionView registerClass:[MineLoveOrCreatCell class] forCellWithReuseIdentifier:NSStringFromClass(MineLoveOrCreatCell.class)];
        _collectionView.alwaysBounceVertical = YES;
        _collectionView.contentInset = UIEdgeInsetsMake(0, 12, 0, 12);
        
        _loadMore = [[LoadMoreControl alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 50) surplusCount:3];
        [_loadMore startLoading];
        __weak __typeof(self) wself = self;
        [_loadMore setOnLoad:^{
            NSLog(@"%ld=====%ld",wself.pageIndex,wself.pageSize);
            [wself loadData:wself.pageIndex pageSize:wself.pageSize];
        }];
        [_collectionView addSubview:_loadMore];
        
    }
    return _collectionView;
}

- (NSMutableArray *)dataSource
{
    if (!_dataSource) {
        _dataSource = [NSMutableArray array];
    }
    return _dataSource;
}

- (MineViewModel *)viewModel
{
    if (!_viewModel) {
        _viewModel = [[MineViewModel alloc] init];
    }
    return _viewModel;
}


@end
