//
//  RequestModel.m
//  stoc
//
//  Created by Michael on 2017/12/27.
//  Copyright © 2017年 Michael. All rights reserved.
//

#import "RequestModel.h"

@implementation RequestModel

@end
