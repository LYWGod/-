//
//  RequestManager.h
//  payment
//
//  Created by 卢达洋 on 2021/7/25.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>
#import "RequestModel.h"
//NSString * _Nullable const kAPI_HOST           = @"https://test.ypypay.com";
NS_ASSUME_NONNULL_BEGIN

#define kAPI_HOST                @"https://test.ypypay.com"
//#define kAPI_HOST                @"https://api.ypypay.com"

// 获取短信验证码
#define SMS_GET_CODE                @"/sms/getCode"

// 验证码登陆
#define SMS_PLOGIN                  @"/sms/plogin"

// 手机号密码登录
#define SMS_PWLOGIN                 @"/sms/pwLogin"

// 手机号注册
#define SMS_REGISTER                @"/sms/register"

// 忘记密码
#define MEMBER_GETPWD               @"/member/getPwd"

// 设置登录密码
#define MEMBER_SETPASSWORD          @"/member/setPassword"

// 设置支付密码
#define MEMBER_SETPAYPASSWORD       @"/member/setPayPassword"

typedef void (^progressCallback)(NSProgress *progress);
typedef void (^completionCallback)(BOOL success,NSString *msg,NSInteger code,id resultObject);
typedef void (^failureCallback)(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error);
typedef NS_ENUM(NSInteger, RequestType) {
    GET,
    POST,
    PUT,
    DELETE
};

typedef NS_ENUM(NSInteger, FileUpType) {
    FileUpTypeTX,       //头像
    FileUpTypeSFZA,     //法人身份证正面
    FileUpTypeSFZB,     //法人身份证背面
    FileUpTypeYHKZA,     //银行卡正面
    FileUpTypeYHKZB,     //银行卡背面
    FileUpTypeYYZZ,     //营业执照
    FileUpTypeDGZHKHXKZ, //对公账户开户许可证
    FileUpTypeDPMT,     //店铺门头
    FileUpTypeSYT,      //收银台
    FileUpTypeDN,       //店内
    FileUpTypeUnknow    //未知类型
};

@interface RequestManager : NSObject
+ (RequestManager *)shareInstance;

@property (nonatomic, strong, readonly) AFHTTPSessionManager *shareManager;

/**
 网络请求

 @param api         接口地址
 @param type       请求方式
 @param parameters  请求参数
 @param completion  请求成功回调
 */
+(void)requestWithApi:(NSString*)api
                 Type:(RequestType)type
           Parameters:(NSDictionary*)parameters
           Completion:(completionCallback)completion;

/**
 上传文件

 @param image           图片文件
 @param type            业务类型
 @param uploadProgress  上传进度回调
 @param completion      请求成功回调
 */
+(void)upLoadImageWithImage:(UIImage*)image
                   Type:(FileUpType)type
               progress:(progressCallback)uploadProgress
             Completion:(completionCallback)completion;
@end

NS_ASSUME_NONNULL_END
