//
//  MineViewModel.h
//  payment
//
//  Created by git on 2021/8/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MineViewModel : NSObject


/// 加载最新视频列表
/// @param successResult 成功回调
- (void)loadNewDataOfVideoListWithPage:(NSInteger)page withSuccess:(void(^)(NSArray *list))successResult;

@end

NS_ASSUME_NONNULL_END
