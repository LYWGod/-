//
//  MineViewModel.m
//  payment
//
//  Created by git on 2021/8/4.
//

#import "MineViewModel.h"
#import "LoveOrCreatModel.h"
#import "AttationListModel.h"
#import "CollectionListModel.h"
#import "RequestManager.h"
#import <MJExtension.h>

@interface MineViewModel ()

/** 点赞页码 */
@property (nonatomic, assign) NSInteger likePage;
/** 关注页码 */
@property (nonatomic, assign) NSInteger attationPage;
/** 收藏页码 */
@property (nonatomic, assign) NSInteger collectionPage;
/** 消费记录页码 */
@property (nonatomic, assign) NSInteger exchangePage;
/** 视频列表页码 */
@property (nonatomic, assign) NSInteger videoPage;

@end

@implementation MineViewModel



/// 加载最新视频列表
/// @param successResult 成功回调
- (void)loadNewDataOfVideoListWithPage:(NSInteger)page withSuccess:(void(^)(NSArray *list))successResult
{
    NSString *pageValue = @"1";// [NSString stringWithFormat:@"%ld",page];
    
    NSString *urlStr = @"/video/list";// @"/video/like/list";
    
    NSDictionary *parameters = @{@"userId":@"4246",
                                 @"current":pageValue,
                                 @"size":@"10"};
    
    [RequestManager requestWithApi:urlStr Type:GET Parameters:parameters Completion:^(BOOL success, NSString * _Nonnull msg, NSInteger code, id  _Nonnull resultObject) {
    
        if (success) {
            LoveOrCreatModel *model = [LoveOrCreatModel mj_objectWithKeyValues:resultObject];
            !successResult ? : successResult(model.records);
        }
        
    }];
}


@end
