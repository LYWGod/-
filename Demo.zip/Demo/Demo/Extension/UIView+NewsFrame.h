//
//  UIView+NewsFrame.h
//  payment
//
//  Created by git on 2021/7/27.
//
//

#import <UIKit/UIKit.h>

@interface UIView (NewsFrame)
@property (nonatomic, assign) CGFloat x;
@property (nonatomic, assign) CGFloat y;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat centerX;
@property (nonatomic, assign) CGFloat centerY;
@property (nonatomic, assign) CGFloat right;
@property (nonatomic, assign) CGFloat bottom;

@property (nonatomic, assign ) CGSize size;
@property (nonatomic, assign ) CGPoint origin;
@property (nonatomic, assign) CGFloat left;
@property (nonatomic, assign) CGFloat top;

- (UIView*)subViewOfClassName:(NSString*)className;


@end
