//
//  VideoPlayer.h
//  payment
//
//  Created by git on 2021/8/2.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, VideoPlayerStatus) {
    VideoPlayerStatusUnload,      // 未加载
    VideoPlayerStatusPrepared,    // 准备播放
    VideoPlayerStatusLoading,     // 加载中
    VideoPlayerStatusPlaying,     // 播放中
    VideoPlayerStatusPaused,      // 暂停
    VideoPlayerStatusEnded,       // 播放完成
    VideoPlayerStatusError        // 错误
};

@class VideoPlayer;

@protocol VideoPlayerDelegate <NSObject>

- (void)player:(VideoPlayer *)player statusChanged:(VideoPlayerStatus)status;

- (void)player:(VideoPlayer *)player currentTime:(float)currentTime totalTime:(float)totalTime progress:(float)progress;

@end

@interface VideoPlayer : NSObject

@property (nonatomic, weak) id<VideoPlayerDelegate>     delegate;

@property (nonatomic, assign) VideoPlayerStatus         status;

@property (nonatomic, assign) BOOL                          isPlaying;


/**
 根据指定url在指定视图上播放视频
 
 @param playView 播放视图
 @param url 播放地址
 */
- (void)playVideoWithView:(UIView *)playView url:(NSString *)url;

/**
 * 获取当前播放时间
 */
- (float)currentVideoTime;

/**
 * 获取视频总时长
 */
- (float)videoTotalTime;

/**
 设置当前播放视频的进度
 */
- (void)setCurrentVideoProgressValue:(float)value withUrl:(NSString *)url;

/**
 停止播放并移除播放视图
 */
- (void)removeVideo;

/**
 暂停播放
 */
- (void)pausePlay;

/**
 恢复播放
 */
- (void)resumePlay;

/**
 重新播放
 */
- (void)resetPlay;

@end

NS_ASSUME_NONNULL_END
