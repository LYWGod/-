//
//  IndustryModel.m
//  payment
//
//  Created by git on 2021/8/12.
//

#import "IndustryModel.h"

@implementation IndustryModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"industryId":@"id"};
}

@end
