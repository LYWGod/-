//
//  LikeModel.m
//  payment
//
//  Created by git on 2021/8/11.
//

#import "LikeModel.h"

@implementation LikeModel

@end
