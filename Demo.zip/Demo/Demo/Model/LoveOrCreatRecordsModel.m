//
//  LoveOrCreatRecordsModel.m
//  payment
//
//  Created by git on 2021/8/4.
//

#import "LoveOrCreatRecordsModel.h"

@implementation LoveOrCreatRecordsModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
     return @{@"descriptionField":@"description",
              @"UID":@"id"};
}

@end
