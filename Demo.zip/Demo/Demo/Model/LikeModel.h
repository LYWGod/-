//
//  LikeModel.h
//  payment
//
//  Created by git on 2021/8/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LikeModel : NSObject

@property (nonatomic, assign) NSInteger likes;

@property (nonatomic, assign) BOOL liked;

@property (nonatomic, strong) NSString *message;

@property (nonatomic, strong) NSString *score;

@property (nonatomic, strong) NSString *total;

@property (nonatomic, strong) NSString *userId;



@end

NS_ASSUME_NONNULL_END
