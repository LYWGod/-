//
//  CollectionModel.h
//  payment
//
//  Created by git on 2021/8/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CollectionModel : NSObject
/** 用户ID */
@property (nonatomic, copy) NSString * userId;
/** 消息 */
@property (nonatomic, copy) NSString * message;
/** 是否收藏 */
@property (nonatomic, assign) BOOL collected;

@property (nonatomic, assign) NSInteger score;
 
@property (nonatomic, assign) NSInteger total;


@end

NS_ASSUME_NONNULL_END
