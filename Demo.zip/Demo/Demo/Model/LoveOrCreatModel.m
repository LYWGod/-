//
//  LoveOrCreatModel.m
//  payment
//
//  Created by git on 2021/8/4.
//

#import "LoveOrCreatModel.h"
#import "LoveOrCreatRecordsModel.h"

@implementation LoveOrCreatModel

+ (NSDictionary *)mj_objectClassInArray {
     return @{@"records" : [LoveOrCreatRecordsModel class]};
}

@end

