//
//  IndustryModel.h
//  payment
//
//  Created by git on 2021/8/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IndustryModel : NSObject

@property (nonatomic, copy) NSString        *cataDesc;
@property (nonatomic, copy) NSString        *cataName;

@property (nonatomic, copy) NSString        *industryId;
@property (nonatomic, copy) NSString        *isHost;

@property (nonatomic, copy) NSString        *parentId;
@property (nonatomic, copy) NSString        *status;

@end

NS_ASSUME_NONNULL_END
