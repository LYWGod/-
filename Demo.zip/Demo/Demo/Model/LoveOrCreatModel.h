//
//  LoveOrCreatModel.h
//  payment
//
//  Created by git on 2021/8/4.
//

#import <Foundation/Foundation.h>

@class LoveOrCreatRecordsModel;

NS_ASSUME_NONNULL_BEGIN

@interface LoveOrCreatModel : NSObject


@property (nonatomic, assign) NSInteger total;

@property (nonatomic, strong) NSArray * orders;

@property (nonatomic, copy) NSString * countId;

@property (nonatomic, assign) BOOL optimizeCountSql;

@property (nonatomic, assign) NSInteger pages;

@property (nonatomic, assign) NSInteger size;

@property (nonatomic, assign) BOOL hitCount;

@property (nonatomic, assign) BOOL searchCount;

@property (nonatomic, copy) NSString * maxLimit;

@property (nonatomic, assign) NSInteger current;

@property (nonatomic, strong) NSArray <LoveOrCreatRecordsModel *> * records;



@end

NS_ASSUME_NONNULL_END
