//
//  CollectionRecordsModel.h
//  payment
//
//  Created by git on 2021/8/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CollectionRecordsModel : NSObject

@property (nonatomic, copy) NSString *address;

@property (nonatomic, copy) NSString *avatar;

@property (nonatomic, copy) NSString *collectDate;

@property (nonatomic, copy) NSString *content;
 
@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, copy) NSString *nickName;

@property (nonatomic, copy) NSString *publisherId;

@property (nonatomic, copy) NSString *publisherType;

@property (nonatomic, copy) NSString *shopAddress;

@property (nonatomic, copy) NSString *shopContent;
 
@property (nonatomic, copy) NSString *shopId;
 
@property (nonatomic, copy) NSString *shopLogo;

@property (nonatomic, copy) NSString *shopName;

@property (nonatomic, copy) NSString *shopPhone;

@property (nonatomic, copy) NSString *shortName;

@property (nonatomic, copy) NSString *userId;

@property (nonatomic, copy) NSString *userName;

@end

NS_ASSUME_NONNULL_END
