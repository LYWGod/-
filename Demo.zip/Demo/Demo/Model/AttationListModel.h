//
//  AttationListModel.h
//  payment
//
//  Created by git on 2021/8/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AttationListModel : NSObject


/** 头像 */
@property (nonatomic, copy) NSString *avatar;
/** 内容 */
@property (nonatomic, copy) NSString *content;
/** 关注日期 */
@property (nonatomic, copy) NSString *followDate;
/** 手机号 */
@property (nonatomic, copy) NSString *mobile;
/** 昵称 */
@property (nonatomic, copy) NSString *nickName;

@property (nonatomic, copy) NSString *publisherId;
 
@property (nonatomic, copy) NSString *publisherType;
 
@property (nonatomic, copy) NSString *shopAddress;

@property (nonatomic, copy) NSString *shopContent;

@property (nonatomic, copy) NSString *shopId;

@property (nonatomic, copy) NSString *shopLogo;
 
@property (nonatomic, copy) NSString *shopName;

@property (nonatomic, copy) NSString *shopPhone;
 
@property (nonatomic, copy) NSString *shortName;

@property (nonatomic, copy) NSString *userId;

@property (nonatomic, copy) NSString *userName;

@end

NS_ASSUME_NONNULL_END
