//
//  BranchBankDataModel.h
//  payment
//
//  Created by git on 2021/8/12.
//

#import <Foundation/Foundation.h>
@class BranchBankModel;

NS_ASSUME_NONNULL_BEGIN

@interface BranchBankDataModel : NSObject

@property (nonatomic, copy)     NSArray <BranchBankModel *>    *records;
@property (nonatomic, copy)     NSString                 *total;

@property (nonatomic, copy)     NSString                 *size;
@property (nonatomic, copy)     NSString                 *current;

@property (nonatomic, copy)     NSArray                  *orders;
@property (nonatomic, assign)   BOOL                     optimizeCountSql;

@property (nonatomic, assign)   BOOL                     hitCount;
@property (nonatomic, copy)     NSString                 *countId;

@property (nonatomic, copy)     NSString                 *maxLimit;
@property (nonatomic, assign)   BOOL                     searchCount;

@property (nonatomic, copy)     NSString                 *pages;

@end

@interface BranchBankModel : NSObject

@property (nonatomic, copy)     NSString                 *bankId;
@property (nonatomic, copy)     NSString                 *bankName;

@property (nonatomic, copy)     NSString                 *city;
@property (nonatomic, copy)     NSString                 *cityId;

@property (nonatomic, copy)     NSString                 *branchBank_id;
@property (nonatomic, copy)     NSString                 *province;

@property (nonatomic, copy)     NSString                 *provinceId;
@property (nonatomic, copy)     NSString                 *sisterBankName;

@property (nonatomic, copy)     NSString                 *sisterBankNumber;

@end

NS_ASSUME_NONNULL_END
