//
//  CollectionListModel.m
//  payment
//
//  Created by git on 2021/8/12.
//

#import "CollectionListModel.h"
#import "CollectionRecordsModel.h"
#import "CollectionOrdersModel.h"

@implementation CollectionListModel


+ (NSDictionary *)mj_objectClassInArray {
     return @{@"records" : [CollectionRecordsModel class],
              @"orders" : [CollectionOrdersModel class]};
}

@end
