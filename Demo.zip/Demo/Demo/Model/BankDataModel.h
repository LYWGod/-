//
//  BankDataModel.h
//  payment
//
//  Created by git on 2021/8/12.
//

#import <Foundation/Foundation.h>
@class BankModel;

NS_ASSUME_NONNULL_BEGIN

@interface BankDataModel : NSObject

@property (nonatomic, copy)     NSArray <BankModel *>    *records;
@property (nonatomic, copy)     NSString                 *total;

@property (nonatomic, copy)     NSString                 *size;
@property (nonatomic, copy)     NSString                 *current;

@property (nonatomic, copy)     NSArray                  *orders;
@property (nonatomic, assign)   BOOL                     optimizeCountSql;

@property (nonatomic, assign)   BOOL                     hitCount;
@property (nonatomic, copy)     NSString                 *countId;

@property (nonatomic, copy)     NSString                 *maxLimit;
@property (nonatomic, assign)   BOOL                     searchCount;

@property (nonatomic, copy)     NSString                 *pages;

@end

@interface BankModel : NSObject

@property (nonatomic, copy)     NSString                 *bankId;
@property (nonatomic, copy)     NSString                 *bankName;
@property (nonatomic, copy)     NSString                 *bankCode;

@end

NS_ASSUME_NONNULL_END
