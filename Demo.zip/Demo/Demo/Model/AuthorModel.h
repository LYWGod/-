//
//  AuthorModel.h
//  payment
//
//  Created by git on 2021/8/2.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AuthorModel : NSObject

@property (nonatomic, copy) NSString        *fans_num;
@property (nonatomic, copy) NSString        *follow_num;
@property (nonatomic, copy) NSString        *gender;
@property (nonatomic, copy) NSString        *intro;
@property (nonatomic, copy) NSString        *is_follow;
@property (nonatomic, copy) NSString        *name_show;
@property (nonatomic, copy) NSString        *portrait;
@property (nonatomic, copy) NSString        *user_id;
@property (nonatomic, copy) NSString        *user_name;


@end

NS_ASSUME_NONNULL_END
