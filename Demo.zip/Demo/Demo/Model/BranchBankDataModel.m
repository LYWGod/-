//
//  BranchBankDataModel.m
//  payment
//
//  Created by git on 2021/8/12.
//

#import "BranchBankDataModel.h"

@implementation BranchBankDataModel

+ (NSDictionary *)mj_objectClassInArray {
     return @{@"records" : [BranchBankModel class]};
}

@end

@implementation BranchBankModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"branchBank_id":@"id"};
}

@end
