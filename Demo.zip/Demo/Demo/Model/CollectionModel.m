//
//  CollectionModel.m
//  payment
//
//  Created by git on 2021/8/12.
//

#import "CollectionModel.h"

@implementation CollectionModel

@end
