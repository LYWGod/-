//
//  AttationModel.h
//  payment
//
//  Created by git on 2021/8/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AttationModel : NSObject


@property (nonatomic, assign) BOOL followed;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, copy) NSString *score;

@property (nonatomic, copy) NSString *total;

@property (nonatomic, copy) NSString *userId;

@end

NS_ASSUME_NONNULL_END
