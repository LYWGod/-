//
//  AttationModel.m
//  payment
//
//  Created by git on 2021/8/11.
//

#import "AttationModel.h"

@implementation AttationModel

@end
