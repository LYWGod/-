//
//  CollectionOrdersModel.h
//  payment
//
//  Created by git on 2021/8/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CollectionOrdersModel : NSObject

@end

NS_ASSUME_NONNULL_END
