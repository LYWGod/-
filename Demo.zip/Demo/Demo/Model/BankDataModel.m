//
//  BankDataModel.m
//  payment
//
//  Created by git on 2021/8/12.
//

#import "BankDataModel.h"

@implementation BankDataModel

+ (NSDictionary *)mj_objectClassInArray {
     return @{@"records" : [BankModel class]};
}

@end

@implementation BankModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"bankId":@"id"};
}

@end
