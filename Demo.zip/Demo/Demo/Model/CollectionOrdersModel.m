//
//  CollectionOrdersModel.m
//  payment
//
//  Created by git on 2021/8/12.
//

#import "CollectionOrdersModel.h"

@implementation CollectionOrdersModel

@end
