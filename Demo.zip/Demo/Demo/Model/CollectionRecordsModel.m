//
//  CollectionRecordsModel.m
//  payment
//
//  Created by git on 2021/8/12.
//

#import "CollectionRecordsModel.h"

@implementation CollectionRecordsModel

@end
