//
//  CollectionListModel.h
//  payment
//
//  Created by git on 2021/8/12.
//

#import <Foundation/Foundation.h>

@class CollectionRecordsModel,CollectionOrdersModel;

NS_ASSUME_NONNULL_BEGIN

@interface CollectionListModel : NSObject

@property (nonatomic, strong) NSArray<CollectionRecordsModel *>*records;

@property (nonatomic, strong) NSArray<CollectionOrdersModel *>*orders;

@property (nonatomic, copy) NSString *countId;

@property (nonatomic, copy) NSString *maxLimit;

@property (nonatomic, copy) NSString *shopPhone;

@property (nonatomic, assign) NSInteger pages;

@property (nonatomic, assign) NSInteger current;

@property (nonatomic, assign) NSInteger hitCount;

@property (nonatomic, assign) NSInteger searchCount;

@property (nonatomic, assign) NSInteger size;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger optimizeCountSql;

@end

NS_ASSUME_NONNULL_END
