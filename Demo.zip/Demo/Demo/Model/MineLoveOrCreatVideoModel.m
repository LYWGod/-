//
//  MineLoveOrCreatVideoModel.m
//  payment
//
//  Created by git on 2021/7/28.
//

#import "MineLoveOrCreatVideoModel.h"
#import "AuthorModel.h"
#import <MJExtension.h>

@implementation MineLoveOrCreatVideoModel

+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"author" : [AuthorModel class]};
}

@end
