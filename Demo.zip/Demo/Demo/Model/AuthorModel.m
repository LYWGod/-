//
//  AuthorModel.m
//  payment
//
//  Created by git on 2021/8/2.
//

#import "AuthorModel.h"

@implementation AuthorModel

@end
