//
//  LoveOrCreatRecordsModel.h
//  payment
//
//  Created by git on 2021/8/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoveOrCreatRecordsModel : NSObject


@property (nonatomic, copy) NSString * latitude;

@property (nonatomic, copy) NSString * content;

@property (nonatomic, copy) NSString * title;

@property (nonatomic, copy) NSString * createTime;

@property (nonatomic, copy) NSString * nickName;

@property (nonatomic, assign) BOOL following;

@property (nonatomic, assign) BOOL liked;

@property (nonatomic, copy) NSString * shopName;

@property (nonatomic, copy) NSString * url;

@property (nonatomic, copy) NSString * descriptionField;

@property (nonatomic, copy) NSString * address;

@property (nonatomic, copy) NSString * createBy;

@property (nonatomic, copy) NSString * avatar;

@property (nonatomic, copy) NSString * updateBy;

@property (nonatomic, copy) NSString * updateTime;

@property (nonatomic, copy) NSString * reason;

@property (nonatomic, copy) NSString *userId;

@property (nonatomic, copy) NSString * shortName;

@property (nonatomic, copy) NSString * userName;

@property (nonatomic, copy) NSString * shopLogo;

@property (nonatomic, copy) NSString * UID;

@property (nonatomic, assign) NSInteger likes;

@property (nonatomic, copy) NSString * shopPhone;

@property (nonatomic, copy) NSString * shopContent;

@property (nonatomic, assign) NSInteger forwards;

@property (nonatomic, assign) NSInteger collected;

@property (nonatomic, copy) NSString * shopAddress;

@property (nonatomic, copy) NSString * longitude;

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, assign) NSInteger shopId;

@property (nonatomic, copy) NSString * cover;

@property (nonatomic, copy) NSString * topic;

@end

NS_ASSUME_NONNULL_END
