//
//  NetworkHelper.m
//  Demo
//
//  Created by git on 2021/8/19.
//

#import "NetworkHelper.h"
#import "AFHTTPSessionManager.h"

@implementation NetworkHelper

NSString *const NetworkStatesChangeNotification = @"NetworkStatesChangeNotification";

//Reachability
+(AFNetworkReachabilityManager *)shareReachabilityManager {
    static dispatch_once_t once;
    static AFNetworkReachabilityManager *manager;
    dispatch_once(&once, ^{
        manager = [AFNetworkReachabilityManager manager];
    });
    return manager;
}

+ (void)startListening {
    [[NetworkHelper shareReachabilityManager] startMonitoring];
    [[NetworkHelper shareReachabilityManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        [[NSNotificationCenter defaultCenter] postNotificationName:NetworkStatesChangeNotification object:nil];
        if(![NetworkHelper isNotReachableStatus:status]) {
        }
    }];
}

+ (AFNetworkReachabilityStatus)networkStatus {
    return [NetworkHelper shareReachabilityManager].networkReachabilityStatus;
}

+ (BOOL)isWifiStatus {
    return [NetworkHelper shareReachabilityManager].networkReachabilityStatus == AFNetworkReachabilityStatusReachableViaWiFi;
}

+ (BOOL)isNotReachableStatus:(AFNetworkReachabilityStatus)status {
    return status == AFNetworkReachabilityStatusNotReachable;
}

@end
