//
//  NetworkHelper.h
//  Demo
//
//  Created by git on 2021/8/19.
//

#import <Foundation/Foundation.h>
#import "AFHTTPSessionManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface NetworkHelper : NSObject

//network state notification
extern NSString *const NetworkStatesChangeNotification;

//Reachability
+ (AFNetworkReachabilityManager *)shareReachabilityManager;

+ (void)startListening;

+ (AFNetworkReachabilityStatus)networkStatus;

+ (BOOL)isWifiStatus;

+ (BOOL)isNotReachableStatus:(AFNetworkReachabilityStatus)status;


@end

NS_ASSUME_NONNULL_END
