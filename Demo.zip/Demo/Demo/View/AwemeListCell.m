//
//  AwemeListCell.m
//  Douyin
//
//  Created by Qiao Shi on 2018/7/30.
//  Copyright © 2018年 Qiao Shi. All rights reserved.
//

#import "AwemeListCell.h"
#import "CircleTextView.h"
#import "MusicAlbumView.h"
#import "FavoriteView.h"
#import "LoveOrCreatRecordsModel.h"
#import "GKDoubleLikeView.h"
#import "GKSliderView.h"
#import "VideoItemBtn.h"
#import "VideoLikeBtn.h"
#import <SDWebImage.h>
#import <Masonry.h>
#import "NSString+Extension.h"
#import "VideoPlayer.h"
#import "GKDYVideoModel.h"
#import <AVFoundation/AVAsset.h>
#import <AVFoundation/AVAssetImageGenerator.h>
#import <AVFoundation/AVTime.h>

#define TABBAR_HEIGHT       (IS_iPhoneX ? 83.0f : 49.0f)

/// 屏幕宽高
#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)

// 判断是否是iPhone X系列
#define IS_iPhoneX          ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? ((NSInteger)(([[UIScreen mainScreen] currentMode].size.height/[[UIScreen mainScreen] currentMode].size.width)*100) == 216) : NO)

// 适配比例
#define ADAPTATIONRATIO     SCREEN_WIDTH / 750.0f


//size
#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height

#define StatusBarHeight [UIApplication sharedApplication].statusBarFrame.size.height
#define SafeAreaTopHeight ((ScreenHeight >= 812.0) && [[UIDevice currentDevice].model isEqualToString:@"iPhone"] ? 88 : 64)
#define SafeAreaBottomHeight ((ScreenHeight >= 812.0) && [[UIDevice currentDevice].model isEqualToString:@"iPhone"]  ? 30 : 0)

static const NSInteger IntegralImageViewTag = 0x01;
static const NSInteger ShareImageViewTag   = 0x02;
static const NSInteger AvatarImageViewTag   = 0x03;

@interface AwemeListCell()<VideoPlayerDelegate,GKSliderViewDelegate>

/** 背景音乐 */
@property (nonatomic, strong) CircleTextView   *musicName;
/** 描述 */
@property (nonatomic, strong) UILabel          *desc;
/** 昵称 */
@property (nonatomic, strong) UILabel          *nickName;
/** 头像 */
@property (nonatomic, strong) UIImageView      *avatar;
/** 音乐 */
@property (nonatomic, strong) MusicAlbumView   *musicAlum;
/** 分享 */
@property (nonatomic, strong) UIImageView      *share;
/** 积分 */
@property (nonatomic, strong) UIImageView      *Integral;
/** 喜欢 */
@property (nonatomic, strong) FavoriteView     *favorite;
/** 分享数量 */
@property (nonatomic, strong) UILabel          *shareNum;
/** 赚积分 */
@property (nonatomic, strong) UILabel          *IntegralNum;
/** 喜欢数量 */
@property (nonatomic, strong) UILabel          *favoriteNum;
/** 双击喜欢 */
@property (nonatomic, strong) GKDoubleLikeView          *doubleLikeView;
/** 进度条 */
@property (nonatomic, strong) GKSliderView                *sliderView;
/** 容器 */
@property (nonatomic, strong) UIView                   *container;
/** 关注 */
@property (nonatomic, strong) UIButton           *attationBtn;
/** 地点按钮 */
@property (nonatomic, strong) UIButton          *placeBtn;

@property (nonatomic ,strong) CAGradientLayer          *gradientLayer;

@property (nonatomic ,strong) UIImageView              *pauseIcon;

@property (nonatomic ,strong) UIImageView              *musicIcon;

@property (nonatomic, strong) UITapGestureRecognizer   *singleTapGesture;

@property (nonatomic, assign) NSTimeInterval           lastTapTime;

@property (nonatomic, assign) CGPoint                  lastTapPoint;
/** 临时处理进度条的一个BOOL值 */
@property (nonatomic, assign) BOOL                     isSlidering;


@end

@implementation AwemeListCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.01];
        _lastTapTime = 0;
        _lastTapPoint = CGPointZero;
//        [self initSubViews];
        _isSlidering = NO;
        [self setupSubViews];
    }
    return self;
}

// update method
- (void)setModel:(GKDYVideoModel *)model{
    
    self.sliderView.value = 0;
    
    _model = model;
//    //昵称
//    _nickName.text = model.nickName.length ? [NSString stringWithFormat:@"@%@", model.nickName] : nil;
//    //内容
//    [_desc setText:model.descriptionField];
//    //音乐
//    [_musicName setText:[model.descriptionField stringByAppendingString:@"原声"]];
//    //喜欢数量
//    [_favoriteNum setText:[NSString stringWithFormat:@"%ld",model.likes]];
//    //分享数量
//    [_shareNum setText:[NSString stringWithFormat:@"%ld",model.likes]];
//    //头像
//    [_avatar sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"touxiang_icon"]];
//
//    UIImage *image = [self getVideoPreViewImage:[NSURL URLWithString:model.url]];
//    self.playerSuperView.image = image;
//    //地点
//    [_placeBtn setTitle:model.address forState:UIControlStateNormal];
//
////    [_playerSuperView sd_setImageWithURL:[NSURL URLWithString:model.cover] placeholderImage:[UIImage imageNamed:@"img_video_loading"]];
//
//
//    CGFloat width = [model.address widthWithFontSize:16 height:30];
//    if (width > SCREEN_WIDTH - 120 ) {
//        [_placeBtn mas_updateConstraints:^(MASConstraintMaker *make) {
//            make.width.mas_equalTo(SCREEN_WIDTH - 120);
//        }];
//    }else{
//        [_placeBtn mas_updateConstraints:^(MASConstraintMaker *make) {
//            make.width.mas_equalTo(width);
//        }];
//    }

}


// 获取视频第一帧
- (UIImage*) getVideoPreViewImage:(NSURL *)path
{
    NSURL *url = path;
    AVURLAsset *asset1 = [[AVURLAsset alloc] initWithURL:url options:nil];
    AVAssetImageGenerator *generate1 = [[AVAssetImageGenerator alloc] initWithAsset:asset1];
    generate1.appliesPreferredTrackTransform = YES;
    NSError *err = NULL;
    CMTime time = CMTimeMake(1, 2);
    CGImageRef oneRef = [generate1 copyCGImageAtTime:time actualTime:NULL error:&err];
    UIImage *one = [[UIImage alloc] initWithCGImage:oneRef];
   
    return one;
}



- (void)setupSubViews {
    _gradientLayer = [CAGradientLayer layer];
    _gradientLayer.colors = @[(__bridge id)[UIColor clearColor].CGColor, (__bridge id)[UIColor colorWithRed:0 green:0 blue:0 alpha:0.2].CGColor, (__bridge id)[UIColor colorWithRed:0 green:0 blue:0 alpha:0.4].CGColor];
    _gradientLayer.locations = @[@0.3, @0.6, @1.0];
    _gradientLayer.startPoint = CGPointMake(0.0f, 0.0f);
    _gradientLayer.endPoint = CGPointMake(0.0f, 1.0f);
    [_container.layer addSublayer:_gradientLayer];
    
    [self.contentView addSubview:self.container];
    [self.container addSubview:self.playerSuperView];
    [self.container addSubview:self.pauseIcon];
    [self.container addSubview:self.sliderView];
    [self.sliderView hideLoading];
    [self.container addSubview:self.musicIcon];
    [self.container addSubview:self.musicName];
    [self.container addSubview:self.desc];
    [self.container addSubview:self.nickName];
    [self.container addSubview:self.placeBtn];
    _musicAlum = [MusicAlbumView new];
    [self.container addSubview:_musicAlum];
    [self.container addSubview:self.share];
    [self.container addSubview:self.shareNum];
    [self.container addSubview:self.Integral];
    [self.container addSubview:self.IntegralNum];
    _favorite = [FavoriteView new];
    [self.container addSubview:self.favorite];
    [self.container addSubview:self.favoriteNum];
    [self.container addSubview:self.avatar];
    [self.container addSubview:self.attationBtn];
    
    
    _singleTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)];
    [self.container addGestureRecognizer:_singleTapGesture];
    
    [self.container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    self.sliderView.frame = CGRectMake(0, SCREEN_HEIGHT - TABBAR_HEIGHT - 0.5, SCREEN_WIDTH, 5.0f);
    
    [_playerSuperView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    [_container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    [_pauseIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
        make.width.height.mas_equalTo(100);
    }];
    
    CGFloat bottomM = TABBAR_HEIGHT;
    [_placeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(10);
        make.bottom.equalTo(self.mas_bottom).offset(-(ADAPTATIONRATIO * 30.0f + bottomM));
        make.width.mas_equalTo(100);
        make.height.mas_equalTo(28);
    }];
    
    [_musicIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.bottom.equalTo(_placeBtn.mas_top).offset(-10);
        make.width.mas_equalTo(30);
        make.height.mas_equalTo(25);
    }];
    
    [_musicName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.musicIcon.mas_right);
        make.centerY.equalTo(self.musicIcon);
        make.width.mas_equalTo(ScreenWidth/2);
        make.height.mas_equalTo(24);
    }];
    
    [_desc mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(10);
        make.bottom.equalTo(self.musicIcon.mas_top);
        make.width.mas_lessThanOrEqualTo(ScreenWidth/5*3);
    }];
    
    [_nickName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(10);
        make.bottom.equalTo(self.desc.mas_top).inset(5);
        make.width.mas_lessThanOrEqualTo(ScreenWidth/4*3 + 30);
    }];
    
    [_musicAlum mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.musicName);
        make.right.equalTo(self).inset(10);
        make.width.height.mas_equalTo(50);
    }];
    
    [_Integral mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.musicAlum.mas_top).inset(50);
        make.right.equalTo(self).inset(15);
        make.width.mas_equalTo(40);
        make.height.mas_equalTo(36);
    }];
    
    [_IntegralNum mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.Integral.mas_bottom).offset(5);
        make.centerX.equalTo(self.share);
    }];
    
    [_share mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.Integral.mas_top).inset(25);
        make.right.equalTo(self).inset(10);
        make.width.mas_equalTo(50);
        make.height.mas_equalTo(45);
    }];
    
    [_shareNum mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.share.mas_bottom);
        make.centerX.equalTo(self.share);
    }];
    
    [_favorite mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.share.mas_top).inset(25);
        make.right.equalTo(self).inset(10);
        make.width.mas_equalTo(50);
        make.height.mas_equalTo(45);
    }];
    
    [_favoriteNum mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.favorite.mas_bottom);
        make.centerX.equalTo(self.favorite);
    }];
    
    CGFloat avatarRadius = 25;
    [_avatar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.favorite.mas_top).inset(35);
        make.right.equalTo(self).inset(10);
        make.width.height.mas_equalTo(avatarRadius*2);
    }];

    [_attationBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.avatar);
        make.centerY.equalTo(self.avatar.mas_bottom);
        make.width.height.mas_equalTo(24);
    }];
}

-(void)layoutSubviews {
    [super layoutSubviews];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    _gradientLayer.frame = CGRectMake(0, self.frame.size.height - 500, self.frame.size.width, 500);
    [CATransaction commit];
}


//gesture
- (void)handleGesture:(UITapGestureRecognizer *)sender {
    switch (sender.view.tag) {
        case AvatarImageViewTag:{
            if (_delegate && [_delegate respondsToSelector:@selector(awemeListCell:didClickAvatarImageView:)]) {
                [_delegate awemeListCell:self didClickAvatarImageView:self.avatar];
            }
            break;
        }
        case IntegralImageViewTag: {
            if (_delegate && [_delegate respondsToSelector:@selector(awemeListCell:didClickIntegralImageView:)]) {
                [_delegate awemeListCell:self didClickIntegralImageView:self.IntegralNum];
            }
            break;
        }
        case ShareImageViewTag: {
            if (_delegate && [_delegate respondsToSelector:@selector(awemeListCell:didClickShareImageView:)]) {
                [_delegate awemeListCell:self didClickShareImageView:self.shareNum];
            }
            break;
        }
        default: {
            //获取点击坐标，用于设置爱心显示位置
            CGPoint point = [sender locationInView:_container];
            //获取当前时间
            NSTimeInterval time = [[NSDate dateWithTimeIntervalSinceNow:0] timeIntervalSince1970];
            //判断当前点击时间与上次点击时间的时间间隔
            if(time - _lastTapTime > 0.25f) {
                //推迟0.25秒执行单击方法
                [self performSelector:@selector(singleTapAction) withObject:nil afterDelay:0.25f];
            }else {
                //取消执行单击方法
                [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(singleTapAction) object: nil];
                //执行连击显示爱心的方法
                [self showLikeViewAnim:point oldPoint:_lastTapPoint];
            }
            //更新上一次点击位置
            _lastTapPoint = point;
            //更新上一次点击时间
            _lastTapTime =  time;
            break;
        }
    }
}

/// 单击屏幕暂停或播放
- (void)singleTapAction {
    if (self.player.isPlaying) {
        [self.player pausePlay];
    }else{
        [self.player resumePlay];
    }
}

/// 显示暂停按钮
- (void)showPlayBtn {
    self.pauseIcon.hidden = NO;
}

/// 隐藏暂停按钮
- (void)hidePlayBtn {
    self.pauseIcon.hidden = YES;
}

///连击点赞动画
- (void)showLikeViewAnim:(CGPoint)newPoint oldPoint:(CGPoint)oldPoint {
    [self.doubleLikeView createAnimationWith:newPoint withSuperView:_container];
}

///加载动画
-(void)startLoadingPlayItemAnim:(BOOL)isStart {
    if (isStart) {
        [self.sliderView showLineLoading];
    } else {
        [self.sliderView hideLineLoading];
    }
}

#pragma mark - VideoPlayerDelegate
- (void)player:(VideoPlayer *)player statusChanged:(VideoPlayerStatus)status
{
    switch (status) {
        case VideoPlayerStatusUnload:   // 未加载
            
            break;
        case VideoPlayerStatusPrepared:   // 准备播放
            [self startLoadingPlayItemAnim:YES];
            break;
        case VideoPlayerStatusLoading: {     // 加载中

        }
            break;
        case VideoPlayerStatusPlaying: {    // 播放中
            [self startLoadingPlayItemAnim:NO];
            [self hidePlayBtn];
        }
            break;
        case VideoPlayerStatusPaused: {     // 暂停
            [self showPlayBtn];
        }
            break;
        case VideoPlayerStatusEnded: {   // 播放结束
            // 重新开始播放
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self.player resetPlay];
            });
        }
            break;
        case VideoPlayerStatusError:   // 错误
            
            break;
            
        default:
            break;
    }
}

- (void)player:(VideoPlayer *)player currentTime:(float)currentTime totalTime:(float)totalTime progress:(float)progress
{
    dispatch_async(dispatch_get_main_queue(), ^{
        //设置进度条的值
        if (self.isSlidering) {
        }else{
//            self.sliderView.value = progress;
            self.sliderView.value = 0.3;//临时给个值  然后进行滑动
            self.isSlidering = YES;
        }
        
    });
}

/// 地点按钮点击
/// @param placeBtn 地点按钮
- (void)placeBtnClick:(UIButton *)placeBtn
{
    if (_delegate && [_delegate respondsToSelector:@selector(awemeListCell:didClickPlaceBtn:)]) {
        [_delegate awemeListCell:self didClickPlaceBtn:placeBtn];
    }
}

/// 关注按钮点击
/// @param attationBtn 关注按钮
- (void)attationClick:(UIButton *)attationBtn
{
    if (_delegate && [_delegate respondsToSelector:@selector(awemeListCell:didClickAttationBtn:)]) {
        [_delegate awemeListCell:self didClickAttationBtn:attationBtn];
    }
}

// 滑块滑动开始
- (void)sliderTouchBegan:(float)value
{
    NSLog(@"滑块滑动开始%f",value);
}
// 滑块滑动中
- (void)sliderValueChanged:(float)value
{
    self.isSlidering = YES;
    NSLog(@"滑块滑动中%f",value);
    self.sliderView.value = value;
}
// 滑块滑动结束
- (void)sliderTouchEnded:(float)value
{
    NSLog(@"滑块滑动结束%f",value);
    self.sliderView.value = value;
    CGFloat  videoTotalTime = [self.player videoTotalTime];
    CGFloat roundA = roundf(videoTotalTime * value);
    [self.player setCurrentVideoProgressValue:roundA withUrl:_model.video_url];
}
// 滑杆点击
- (void)sliderTapped:(float)value
{
    NSLog(@"滑杆点击%f",value);
}

#pragma mark - 懒加载
- (GKDoubleLikeView *)doubleLikeView {
    if (!_doubleLikeView) {
        _doubleLikeView = [[GKDoubleLikeView alloc] init];
    }
    return _doubleLikeView;
}

- (GKSliderView *)sliderView {
    if (!_sliderView) {
        _sliderView = [[GKSliderView alloc] init];
//        _sliderView.isHideSliderBlock = YES;
        _sliderView.allowTapped = YES;
        _sliderView.delegate = self;
        _sliderView.sliderHeight = 5.0f;
        _sliderView.maximumTrackTintColor = [UIColor clearColor];
        _sliderView.minimumTrackTintColor = [UIColor whiteColor];
        _sliderView.bufferTrackTintColor = [UIColor redColor];
    }
    return _sliderView;
}

- (CircleTextView *)musicName
{
    if (!_musicName) {
        _musicName = [[CircleTextView alloc]init];
        _musicName.textColor = [UIColor whiteColor];
        _musicName.font = [UIFont systemFontOfSize:14.0];
    }
    return _musicName;
}

- (UIImageView *)musicIcon
{
    if (!_musicIcon) {
        _musicIcon = [[UIImageView alloc]init];
        _musicIcon.contentMode = UIViewContentModeCenter;
        _musicIcon.image = [UIImage imageNamed:@"icon_home_musicnote3"];
    }
    return _musicIcon;
}

- (UIView *)container
{
    if (!_container) {
        _container = [[UIView alloc] init];
    }
    return _container;
}


- (UIImageView *)share
{
    if (!_share) {
        _share = [[UIImageView alloc]init];
        _share.contentMode = UIViewContentModeCenter;
        _share.image = [UIImage imageNamed:@"icon_home_share"];
        _share.userInteractionEnabled = YES;
        _share.tag = ShareImageViewTag;
        [_share addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)]];
    }
    return _share;
}

- (UILabel *)nickName {
    if (!_nickName) {
        _nickName = [[UILabel alloc]init];
        _nickName.textColor = [UIColor whiteColor];
        _nickName.font = [UIFont boldSystemFontOfSize:15.0f];
    }
    return _nickName;
}

- (UILabel *)desc {
    if (!_desc) {
        _desc = [[UILabel alloc]init];
        _desc.numberOfLines = 0;
        _desc.textColor = [UIColor whiteColor];
        _desc.font = [UIFont systemFontOfSize:14.0f];
    }
    return _desc;
}

- (UILabel *)shareNum {
    if (!_shareNum) {
        _shareNum = [[UILabel alloc]init];
        _shareNum.text = @"0";
        _shareNum.textColor = [UIColor whiteColor];
        _shareNum.font = [UIFont systemFontOfSize:10.0];
    }
    return _shareNum;
}

- (UIImageView *)Integral
{
    if (!_Integral) {
        _Integral = [[UIImageView alloc]init];
        _Integral.contentMode = UIViewContentModeScaleAspectFit;
        _Integral.image = [UIImage imageNamed:@"goldcoin_icon"];
        _Integral.userInteractionEnabled = YES;
        _Integral.tag = IntegralImageViewTag;
        [_Integral addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)]];
    }
    return _Integral;
}

- (UILabel *)IntegralNum
{
    if (!_IntegralNum) {
        _IntegralNum = [[UILabel alloc]init];
        _IntegralNum.text = @"赚积分";
        _IntegralNum.textColor = [UIColor whiteColor];
        _IntegralNum.font = [UIFont systemFontOfSize:10.0];
    }
    return _IntegralNum;
}

- (UILabel *)favoriteNum
{
    if (!_favoriteNum) {
        _favoriteNum = [[UILabel alloc]init];
        _favoriteNum.text = @"0";
        _favoriteNum.textColor = [UIColor whiteColor];
        _favoriteNum.font = [UIFont systemFontOfSize:10.0];
    }
    return _favoriteNum;
}

- (UIImageView *)avatar
{
    if (!_avatar) {
        CGFloat avatarRadius = 25;
        _avatar = [[UIImageView alloc] init];
        _avatar.image = [UIImage imageNamed:@"img_find_default"];
        _avatar.layer.cornerRadius = avatarRadius;
        _avatar.layer.masksToBounds = YES;
        _avatar.layer.borderColor = [UIColor whiteColor].CGColor;
        _avatar.layer.borderWidth = 1;
        _avatar.tag = AvatarImageViewTag;
        [_avatar addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)]];

    }
    return _avatar;
}

- (UIButton *)attationBtn {
    if (!_attationBtn) {
        _attationBtn = [[UIButton alloc] init];
        _attationBtn.layer.cornerRadius = 12;
        _attationBtn.layer.masksToBounds = YES;
        [_attationBtn setTitle:@"+" forState:UIControlStateNormal];
        [_attationBtn setBackgroundColor:[UIColor redColor]];
        [_attationBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_attationBtn addTarget:self action:@selector(attationClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _attationBtn;
}


- (UIImageView *)pauseIcon {
    if (!_pauseIcon) {
        _pauseIcon = [[UIImageView alloc] init];
        _pauseIcon.image = [UIImage imageNamed:@"icon_play_pause"];
        _pauseIcon.contentMode = UIViewContentModeCenter;
        _pauseIcon.layer.zPosition = 3;
        _pauseIcon.hidden = YES;
    }
    return _pauseIcon;
}


- (UIButton *)placeBtn {
    if (!_placeBtn) {
        _placeBtn = [[UIButton alloc] init];
        _placeBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        _placeBtn.layer.backgroundColor = [UIColor lightGrayColor].CGColor;
        _placeBtn.layer.masksToBounds = YES;
        _placeBtn.layer.cornerRadius = 14;
        _placeBtn.alpha = 0.5;
        _placeBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        _placeBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
        _placeBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 0);
        [_placeBtn setImage:[UIImage imageNamed:@"site_icon"] forState:UIControlStateNormal];
        [_placeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_placeBtn addTarget:self action:@selector(placeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _placeBtn;
}


- (VideoPlayer *)player {
    if (!_player) {
        _player = [VideoPlayer new];
        _player.delegate = self;
    }
    return _player;
}

- (UIImageView *)playerSuperView
{
    if (!_playerSuperView) {
        _playerSuperView = [[UIImageView alloc] init];
        _playerSuperView.contentMode = UIViewContentModeScaleAspectFill;
        _playerSuperView.clipsToBounds = YES;
    }
    return _playerSuperView;
}

@end
