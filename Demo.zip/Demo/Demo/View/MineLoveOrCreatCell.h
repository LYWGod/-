//
//  MineLoveOrCreatCell.h
//  payment
//
//  Created by git on 2021/7/29.
//

#import <UIKit/UIKit.h>
#import "GKDYVideoModel.h"


NS_ASSUME_NONNULL_BEGIN

@interface MineLoveOrCreatCell : UICollectionViewCell

@property (nonatomic, strong) GKDYVideoModel  *model;

@property (nonatomic, strong) UIImageView   *coverImgView;

@property (nonatomic, strong) NSString *titleStr;

@end

NS_ASSUME_NONNULL_END
