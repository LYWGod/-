//
//  MineIntegralBtn.h
//  payment
//
//  Created by git on 2021/7/29.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MineIntegralBtn : UIButton

@end

NS_ASSUME_NONNULL_END
