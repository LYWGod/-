//
//  VideoItemBtn.h
//  payment
//
//  Created by git on 2021/8/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VideoItemBtn : UIButton

@end

NS_ASSUME_NONNULL_END
