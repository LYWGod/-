//
//  MineIntegralBtn.m
//  payment
//
//  Created by git on 2021/7/29.
//

#import "MineIntegralBtn.h"

@implementation MineIntegralBtn


-(void)layoutSubviews
{
    [super layoutSubviews];
    CGRect titleLabelFrame = self.titleLabel.frame;
    titleLabelFrame.origin.x = 5;
    self.titleLabel.frame = titleLabelFrame;
    
    CGRect imageViewFrame = self.imageView.frame;
    imageViewFrame.origin.x = titleLabelFrame.size.width+5;
    self.imageView.frame = imageViewFrame;
}

@end
