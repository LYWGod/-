//
//  VideoItemBtn.m
//  payment
//
//  Created by git on 2021/8/11.
//

#import "VideoItemBtn.h"
#import "UIView+NewsFrame.h"

@implementation VideoItemBtn


- (void)layoutSubviews {

    [super layoutSubviews];
    
    self.imageView.width = self.width;
    self.imageView.height = self.imageView.width;
    self.imageView.centerX = self.width * 0.5;
    self.imageView.y = 0;
    
    self.titleLabel.width = self.width;
    self.titleLabel.y = CGRectGetMaxY(self.imageView.frame) + 8;
    self.titleLabel.x = 0;
    self.titleLabel.height = self.height - self.titleLabel.y;
}

@end
