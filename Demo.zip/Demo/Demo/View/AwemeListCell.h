//
//  AwemeListCell.h
//  Douyin
//
//  Created by Qiao Shi on 2018/7/30.
//  Copyright © 2018年 Qiao Shi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoPlayer.h"

@class LoveOrCreatRecordsModel;
@class GKDYVideoModel;
typedef void (^OnPlayerReady)(void);

@class VideoPlayer;
@class HoverTextView;
@class CircleTextView;
@class FocusView;
@class MusicAlbumView;
@class FavoriteView;
@class AwemeListCell;
@class VideoItemBtn;
@class VideoLikeBtn;

@protocol AwemeListCellDelegate <NSObject>

- (void)awemeListCell:(AwemeListCell *)cell didClickAvatarImageView:(UIImageView *)avatar;

- (void)awemeListCell:(AwemeListCell *)cell didClickIntegralImageView:(UILabel *)IntegralNum;

- (void)awemeListCell:(AwemeListCell *)cell didClickShareImageView:(UILabel *)shareNum;

- (void)awemeListCell:(AwemeListCell *)cell didClickAttationBtn:(UIButton *)attationBtn;

- (void)awemeListCell:(AwemeListCell *)cell didClickPlaceBtn:(UIButton *)placeBtn;


@end


@interface AwemeListCell : UITableViewCell

@property (nonatomic, weak) id<AwemeListCellDelegate> delegate;

@property (nonatomic, strong) GKDYVideoModel            *model;

@property (nonatomic, strong) UIImageView     *playerSuperView;

@property (nonatomic, strong) VideoPlayer          *player;

-(void)startLoadingPlayItemAnim:(BOOL)isStart;

@end
