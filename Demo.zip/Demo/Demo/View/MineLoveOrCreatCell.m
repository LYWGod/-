//
//  MineLoveOrCreatCell.m
//  payment
//
//  Created by git on 2021/7/29.
//

#import "MineLoveOrCreatCell.h"
#import "LoveOrCreatRecordsModel.h"
#import <SDWebImage.h>
#import <Masonry.h>
#import "GKDYVideoModel.h"

#import <AVFoundation/AVAsset.h>
#import <AVFoundation/AVAssetImageGenerator.h>
#import <AVFoundation/AVTime.h>

@interface MineLoveOrCreatCell()

/** 播放量按钮 */
@property (nonatomic, strong) UIButton *starBtn;
/** 状态按钮 */
@property (nonatomic, strong) UILabel *statusLab;

@end

@implementation MineLoveOrCreatCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupSubViews];
    }
    return self;
}


- (void)setModel:(GKDYVideoModel *)model {
    _model = model;

    
//    UIImage *image = [self getVideoPreViewImage:[NSURL URLWithString:model.url]];
//    self.coverImgView.image = image;
    
//    [self.coverImgView sd_setImageWithURL:[NSURL URLWithString:model.cover] placeholderImage:[UIImage imageNamed:@"Mine_love_placeHolder"]];
//    [self.starBtn setTitle:@(model.likes).stringValue forState:UIControlStateNormal];
    
    [self.coverImgView sd_setImageWithURL:[NSURL URLWithString:model.thumbnail_url] placeholderImage:[UIImage imageNamed:@"img_video_loading"]];


}


// 获取视频第一帧
- (UIImage*) getVideoPreViewImage:(NSURL *)path
{
    NSURL *url = path;
    AVURLAsset *asset1 = [[AVURLAsset alloc] initWithURL:url options:nil];
    AVAssetImageGenerator *generate1 = [[AVAssetImageGenerator alloc] initWithAsset:asset1];
    generate1.appliesPreferredTrackTransform = YES;
    NSError *err = NULL;
    CMTime time = CMTimeMake(1, 2);
    CGImageRef oneRef = [generate1 copyCGImageAtTime:time actualTime:NULL error:&err];
    UIImage *one = [[UIImage alloc] initWithCGImage:oneRef];
   
    return one;
}


- (void)setTitleStr:(NSString *)titleStr
{
    _titleStr = titleStr;
    if ([titleStr containsString:@"作品"]) {
        _statusLab.hidden = NO;
    }else{
        _statusLab.hidden = YES;
    }
}

- (void)setupSubViews
{
    [self.contentView addSubview:self.coverImgView];
    [self.contentView addSubview:self.starBtn];
    [self.coverImgView addSubview:self.statusLab];
    
    [self.coverImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.contentView);
    }];
    
    [self.starBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(12.0f);
        make.bottom.equalTo(self.contentView).offset(-12.0f);
    }];
    
    [self.statusLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(6);
        make.right.offset(-6);
        make.width.offset(48);
        make.height.offset(24);
    }];
}

#pragma mark - 懒加载
- (UIImageView *)coverImgView {
    if (!_coverImgView) {
        _coverImgView = [UIImageView new];
        _coverImgView.contentMode = UIViewContentModeScaleAspectFill;
        _coverImgView.clipsToBounds = YES;
        _coverImgView.layer.masksToBounds = YES;
        _coverImgView.layer.cornerRadius = 8;
    }
    return _coverImgView;
}

- (UIButton *)starBtn {
    if (!_starBtn) {
        _starBtn = [UIButton new];
        [_starBtn setImage:[UIImage imageNamed:@"play_quantity_icon"] forState:UIControlStateNormal];
        _starBtn.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_starBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_starBtn setTitle:@"123" forState:UIControlStateNormal];
        _starBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -5);
    }
    return _starBtn;
}

- (UILabel *)statusLab {
    if (!_statusLab) {
        _statusLab = [[UILabel alloc] init];
        _statusLab.font = [UIFont systemFontOfSize:12.0f];
        _statusLab.textAlignment = NSTextAlignmentCenter;
        _statusLab.textColor = [UIColor whiteColor];
        _statusLab.layer.masksToBounds = YES;
        _statusLab.layer.cornerRadius = 8;
//        _statusLab.text = @"未通过";
//        _statusLab.backgroundColor = [UIColor colorWithHex:@"#FF0000"];
        _statusLab.text = @"审核中";
        _statusLab.backgroundColor = [UIColor lightGrayColor];
    }
    return _statusLab;
}

@end
