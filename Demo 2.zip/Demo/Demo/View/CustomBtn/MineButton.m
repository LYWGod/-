//
//  MineButton.m
//  payment
//
//  Created by git on 2021/7/27.
//

#import "MineButton.h"
#import "UIView+NewsFrame.h"
@implementation MineButton


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = [UIFont systemFontOfSize:11];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
//    self.imageView.width = self.width * 0.5;
//    self.imageView.height = self.imageView.width;
    self.imageView.centerX = self.width * 0.5;
    self.imageView.y = 10;
    
    self.titleLabel.width = self.width;
    self.titleLabel.y = CGRectGetMaxY(self.imageView.frame) + 8;
    self.titleLabel.x = 0;
    self.titleLabel.height = self.height - self.titleLabel.y;
}

@end
