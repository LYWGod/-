//
//  GKDoubleLikeView.h
//  GKDYVideo
//
//  Created by gaokun on 2019/6/19.
//  Copyright © 2019 QuintGao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GKDoubleLikeView : NSObject

/// 连击点赞，向上飘放大消失动画
/// @param point 点击位置
/// @param superView 父容器
- (void)createAnimationWith:(CGPoint)point withSuperView:(UIView *)superView;


/// 连击点赞，原地放大消失动画
/// @param newPoint 新位置
/// @param oldPoint 老位置
/// @param superView 父容器
- (void)showDoubleClickLikeViewAnimPint:(CGPoint)newPoint withOldPoint:(CGPoint)oldPoint withSuperView:(UIView *)superView;

@end

NS_ASSUME_NONNULL_END
