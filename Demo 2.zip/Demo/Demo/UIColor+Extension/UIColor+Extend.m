//
//  UIColor+Extend.m
//  payment
//
//  Created by git on 2021/7/27.
//
//

#import "UIColor+Extend.h"

@implementation UIColor (Extend)

- (float)r {
    NSString *RGBValue = [NSString stringWithFormat:@"%@",self];
    //将RGB值描述分隔成字符串
    NSArray *RGBArr = [RGBValue componentsSeparatedByString:@" "];
    if (RGBArr.count == 3) {
        return 0.0;
    }
    float colorR = ((NSString *)RGBArr[1]).floatValue;
    return colorR;
}

- (float)g {
    NSString *RGBValue = [NSString stringWithFormat:@"%@",self];
    //将RGB值描述分隔成字符串
    NSArray *RGBArr = [RGBValue componentsSeparatedByString:@" "];
    if (RGBArr.count == 3) {
        return 0.0;
    }
    float colorG = ((NSString *)RGBArr[2]).floatValue;
    return colorG;
}

- (float)b {
    NSString *RGBValue = [NSString stringWithFormat:@"%@",self];
    //将RGB值描述分隔成字符串
    NSArray *RGBArr = [RGBValue componentsSeparatedByString:@" "];
    if (RGBArr.count == 3) {
        return 0.0;
    }
    float colorB = ((NSString *)RGBArr[3]).floatValue;
    return colorB;
}

- (float)apha {
    NSString *RGBValue = [NSString stringWithFormat:@"%@",self];
    //将RGB值描述分隔成字符串
    NSArray *RGBArr = [RGBValue componentsSeparatedByString:@" "];
    if (RGBArr.count == 3) {
        float colorA = ((NSString *)RGBArr[1]).floatValue;
        return colorA;
    }
    float colorA = ((NSString *)RGBArr[4]).floatValue;
    return colorA;
}

+ (UIColor *) colorWithHexString:(NSString *)color andAlpha:(float)alpha
{
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) {
        return [UIColor clearColor];
    }
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"])
        cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor clearColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    
    //r
    NSString *rString = [cString substringWithRange:range];
    
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f) green:((float) g / 255.0f) blue:((float) b / 255.0f) alpha:alpha];
}

+ (UIColor *)colorWithHexString:(NSString *)color
{
   return [UIColor colorWithHexString:color andAlpha:1];
}

+ (UIImage *) getImageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0, 0, 100, 100);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

+ (UIColor *)colorWithHex:(NSString *)string
{
    NSString *cleanString = [string stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if([cleanString length] == 3) {
        cleanString = [NSString stringWithFormat:@"%@%@%@%@%@%@",
                       [cleanString substringWithRange:NSMakeRange(0, 1)],[cleanString substringWithRange:NSMakeRange(0, 1)],
                       [cleanString substringWithRange:NSMakeRange(1, 1)],[cleanString substringWithRange:NSMakeRange(1, 1)],
                       [cleanString substringWithRange:NSMakeRange(2, 1)],[cleanString substringWithRange:NSMakeRange(2, 1)]];
    }
    if([cleanString length] == 6) {
        cleanString = [cleanString stringByAppendingString:@"ff"];
    }
    
    unsigned int baseValue;
    [[NSScanner scannerWithString:cleanString] scanHexInt:&baseValue];
    
    float red = ((baseValue >> 24) & 0xFF)/255.0f;
    float green = ((baseValue >> 16) & 0xFF)/255.0f;
    float blue = ((baseValue >> 8) & 0xFF)/255.0f;
    
    return [UIColor colorWithRed:red green:green blue:blue alpha:1.0];
}

+ (UIColor*)TY_NavBG_Color
{
    return [UIColor colorWithHex:@"#db2920"];
}

+ (UIColor*)TY_NavTitle_Color
{
    return [UIColor colorWithHex:@"#B52519"];
}

+ (NSString*)TY_TabTitle_NColor
{
    return @"#878686";//[UIColor colorWithRed:142/255.0 green:124/255.0 blue:122/255.0 alpha:1];
}

+ (NSString*)TY_TabTitle_SColor
{
    return @"B52519";//[UIColor colorWithRed:201/255.0 green:60/255.0 blue:44/255.0 alpha:1];
}

+ (UIColor*)TY_News_TitleColor
{
    return [UIColor colorWithHex:@"313131"];
}

+ (UIColor*)TY_News_TimeColor
{
    return [UIColor lightGrayColor];
}

+ (UIColor*)TY_Kuaixun_TitleColor
{
    return [UIColor colorWithHex:@"313131"];
}

+ (UIColor*)TY_StockList_TitleColor
{
    return [UIColor darkGrayColor];
}

+ (UIColor*)TY_Setting_TitleColor
{
    return [UIColor colorWithHex:@"313131"];
}

+ (UIColor*)TY_ColBG_GrayColor
{
    return [UIColor colorWithRed:240/255.0 green:241/255.0 blue:242/255.0 alpha:1];
}

+ (UIColor*)TY_ColTitle_NColor
{
    return [UIColor colorWithRed:147/255.0 green:144/255.0 blue:125/255.0 alpha:1];
}

+ (UIColor*)TY_ColTitle_SColor
{
    return [UIColor colorWithRed:201/255.0 green:60/255.0 blue:44/255.0 alpha:1];
}

+ (UIColor*)TY_StockTitle_RedColor
{
    return [UIColor colorWithRed:216/255.0 green:38/255.0 blue:26/255.0 alpha:1.0];
}

+ (UIColor*)TY_StockTitle_GreenColor
{
    return [UIColor colorWithRed:33/255.0 green:161/255.0 blue:86/255.0 alpha:1.0];
}

@end
