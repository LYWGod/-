//
//  UIColor+Extend.h
//  payment
//
//  Created by git on 2021/7/27.
//
//

#import <UIKit/UIKit.h>

/**
 * 颜色分类
 */
@interface UIColor (Extend)

@property (nonatomic, assign) float r;
@property (nonatomic, assign) float g;
@property (nonatomic, assign) float b;
@property (nonatomic, assign) float apha;

+ (UIColor *) colorWithHexString:(NSString *)color andAlpha:(float)alpha;

+ (UIImage *) getImageWithColor:(UIColor *)color;

//获取颜色根据16进制（两个都可以用）
//+ (UIColor *) colorWithHexString:(NSString *)color;
+ (UIColor *)colorWithHex:(NSString *)string;


/**
 *统一颜色值
 **/

//导航栏背景颜色
+ (UIColor*)TY_NavBG_Color;
//导航栏文字颜色
+ (UIColor*)TY_NavTitle_Color;
//底部tab文字颜色(正常)
+ (NSString*)TY_TabTitle_NColor;
//底部tab文字颜色(选中)
+ (NSString*)TY_TabTitle_SColor;
//首页新闻标题颜色
+ (UIColor*)TY_News_TitleColor;
//首页新闻时间颜色
+ (UIColor*)TY_News_TimeColor;

//快讯列表文字颜色
+ (UIColor*)TY_Kuaixun_TitleColor;
//自选列表文字颜色
+ (UIColor*)TY_StockList_TitleColor;
//我的模块文字颜色
+ (UIColor*)TY_Setting_TitleColor;

//滚动频道背景颜色
+ (UIColor*)TY_ColBG_GrayColor;
//首页滚动频道标题的颜色（正常）
+ (UIColor*)TY_ColTitle_NColor;
//首页滚动频道标题的颜色（选中）
+ (UIColor*)TY_ColTitle_SColor;

//股票文字颜色（红）
+ (UIColor*)TY_StockTitle_RedColor;
//股票文字颜色（绿）
+ (UIColor*)TY_StockTitle_GreenColor;

@end
