//
//  RequestModel.h
//  stoc
//
//  Created by Michael on 2017/12/27.
//  Copyright © 2017年 Michael. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RequestModel : NSObject

@property (nonatomic, strong) id data;

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *msg;

@end
