//
//  RequestManager.m
//  payment
//
//  Created by 卢达洋 on 2021/7/25.
//

#import "RequestManager.h"
#import <MJExtension/MJExtension.h>
#import <SDWebImage.h>

static RequestManager *_instance = nil;
static AFHTTPSessionManager *_shareSessionManager = nil;

//NSString *const kAPI_HOST           = @"https://api.ypypay.com";

@implementation RequestManager
+ (RequestManager *)shareInstance
{
    if (!_instance) {
        @synchronized (self) {
            if (!_instance) {
                _instance = [[self alloc] init];
            }
        }
    }
    return _instance;
}

+ (instancetype)sharedInstance {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
        
    });
    return instance;
}

- (AFHTTPSessionManager *)shareManager {
    if (!_shareSessionManager) {
        @synchronized(self) {
            if (!_shareSessionManager) {
                _shareSessionManager = [AFHTTPSessionManager manager];
                _shareSessionManager.requestSerializer = [AFJSONRequestSerializer serializer];
                _shareSessionManager.responseSerializer = [AFJSONResponseSerializer serializer];
                _shareSessionManager.responseSerializer.acceptableContentTypes =
                [NSSet setWithObjects:@"application/json",@"text/json", @"text/JavaScript",@"text/html",@"text/plain",nil];
                // 超时设置
                _shareSessionManager.requestSerializer.timeoutInterval = 60.0;
                //设置允许不信任证书HTTPS请求
                AFSecurityPolicy *security = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
                [security setValidatesDomainName:NO];
                security.allowInvalidCertificates = YES;
                _shareSessionManager.securityPolicy = security;
                
            }
        }
    }
    return _shareSessionManager;
}

/**
 网络请求

 @param api         接口地址
 @param type       请求方式
 @param parameters  请求参数
 @param completion  请求成功回调
 */
+(void)requestWithApi:(NSString*)api
                 Type:(RequestType)type
           Parameters:(NSDictionary*)parameters
           Completion:(completionCallback)completion
{
    NSString *apiUrl = [kAPI_HOST stringByAppendingString:api];
    AFHTTPSessionManager *manager = [RequestManager shareInstance].shareManager;
    void (^progress)(NSProgress * _Nonnull downloadProgress) = ^(NSProgress * _Nonnull downloadProgress) {
        NSLog(@"已完成%f%%",1.0 * downloadProgress.completedUnitCount / downloadProgress.totalUnitCount);
    };
    void (^success)(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) = ^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *response = responseObject;
        NSLog(@"%@",[response mj_JSONObject]);
        RequestModel *Object;
        Object = [[RequestModel alloc] mj_setKeyValues:response];
        if (Object.code == 0) {
            completion(YES,Object.msg,Object.status,Object.data);
        }else{
            completion(NO,Object.msg,Object.status,Object.data);
        }
    };
    void (^failure)(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) = ^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(NO,[error.userInfo objectForKey:@"NSLocalizedDescription"],0,NSNull.null);
    };
    
    
    NSLog(@"网络请求url：\n%@\n请求参数：\n%@",apiUrl,[parameters mj_JSONString]);
    switch (type) {
        case GET:
        {
            [manager GET:apiUrl parameters:parameters headers:nil progress:progress success:success failure:failure];
        }
            break;
        case POST:
        {
            manager.requestSerializer = [AFHTTPRequestSerializer serializer];
            [manager.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", @"text/plain",nil];
            [manager POST:apiUrl parameters:parameters headers:nil progress:progress success:success failure:failure];

        }
            break;
        case PUT:
        {
            [manager PUT:apiUrl parameters:parameters headers:nil success:success failure:failure];
        }
            break;
        case DELETE:
        {
            [manager DELETE:apiUrl parameters:parameters headers:nil success:success failure:failure];
        }
            break;
            
        default:
            break;
    }
}

/**
 上传图片

 @param image           图片
 @param uploadProgress  上传进度回调
 @param completion      请求成功回调
 */
+(void)upLoadImageWithImage:(UIImage*)image
                   Type:(FileUpType)type
               progress:(progressCallback)uploadProgress
             Completion:(completionCallback)completion
{
    NSString *apiUrl = [kAPI_HOST stringByAppendingString:@"/fileUp/priOss"];
    NSDictionary *parameters = NSDictionary.new;
    NSArray *types = @[@"avatar",@"法人身份证正面",@"法人身份证背面",@"银行卡正面",@"银行卡背面",@"营业执照",@"对公账户开户许可证",@"店铺门头",@"收银台",@"店内",@"unknow"];
    if (type == FileUpTypeTX) {
        parameters = @{@"prefix":types[type]};
    }else if (type != FileUpTypeUnknow) {
        parameters = @{@"folder":types[type]};
    }
    AFHTTPSessionManager *manager = [RequestManager shareInstance].shareManager;
    void (^progress)(NSProgress * _Nonnull downloadProgress) = ^(NSProgress * _Nonnull downloadProgress) {
        NSLog(@"已完成%f%%",1.0 * downloadProgress.completedUnitCount / downloadProgress.totalUnitCount);
    };
    void (^success)(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) = ^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *response = responseObject;
        NSLog(@"%@",[response mj_JSONObject]);
        RequestModel *Object;
        Object = [[RequestModel alloc] mj_setKeyValues:response];
        if (Object.code == 0) {
            completion(YES,Object.msg,Object.status,Object.data);
        }else{
            completion(NO,Object.msg,Object.status,Object.data);
        }
    };
    void (^failure)(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) = ^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(NO,[error.userInfo objectForKey:@"NSLocalizedDescription"],0,NSNull.null);
    };
    
    [manager POST:apiUrl parameters:parameters headers:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSDate *date = [NSDate date];
           NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
           [formatter setDateStyle:NSDateFormatterMediumStyle];
           [formatter setTimeStyle:NSDateFormatterShortStyle];
           [formatter setDateFormat:@"YYYYMMddhhmmss"];
        NSString *DateTime = [formatter stringFromDate:date];
        [formData appendPartWithFileData:[image sd_imageData] name:@"file" fileName:[NSString stringWithFormat:@"%@.png",DateTime] mimeType:@"image/png"];
    } progress:progress success:success failure:failure];
    
}

@end
