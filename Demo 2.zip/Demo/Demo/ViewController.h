//
//  ViewController.h
//  Demo
//
//  Created by LYW on 2021/6/3.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, copy) void(^itemClickBlock)(NSArray *videos, NSInteger index);

/** collectionView */
@property (nonatomic,strong) UICollectionView *collectionView;

@property (nonatomic, assign) NSInteger         selectIndex;

@end

