//
//  NSString+Extension.h
//  Douyin
//
//  Created by Qiao Shi on 2018/7/30.
//  Copyright © 2018年 Qiao Shi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSString (Extension)

//- (CGSize)singleLineSizeWithAttributeText:(UIFont *)font;

- (CGSize)singleLineSizeWithText:(UIFont *)font;

- (NSURL *)urlScheme:(NSString *)scheme;

- (CGFloat)widthWithFontSize:(CGFloat)fontSize height:(CGFloat)maxHeight;

@end
