//
//  GKDYVideoModel.m
//  GKDYVideo
//
//  Created by QuintGao on 2018/9/23.
//  Copyright © 2018 QuintGao. All rights reserved.
//

#import "GKDYVideoModel.h"
#import <MJExtension.h>
@implementation GKDYVideoAuthorModel

@end

@implementation GKDYVideoModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"author" : [GKDYVideoAuthorModel class]};
}

@end
